(function () {
	'use strict';

	function init(root) {
		var tabs = [].slice.call(root.querySelectorAll('.iag-tab'));
		var input = root.querySelector('.iag-search__input');
		var cards = [].slice.call(root.querySelectorAll('.iag-card'));
		var grid = root.querySelector('.iag-grid');
		var none = root.querySelector('.iag-empty--filter');
		var filter = 'all';

		function apply() {
			var q = input ? input.value.trim().toLowerCase() : '';
			var shown = 0;
			cards.forEach(function (card) {
				var cats = (card.getAttribute('data-cats') || '').split(' ');
				var okCat = filter === 'all' || cats.indexOf(filter) > -1;
				var okSearch = !q || (card.getAttribute('data-search') || '').indexOf(q) > -1;
				var ok = okCat && okSearch;
				card.hidden = !ok;
				if (ok) { shown++; }
			});
			if (grid) { grid.hidden = shown === 0; }
			if (none) { none.hidden = !(cards.length && shown === 0); }
		}

		tabs.forEach(function (tab) {
			tab.addEventListener('click', function () {
				filter = tab.getAttribute('data-filter');
				tabs.forEach(function (t) {
					var on = t === tab;
					t.classList.toggle('is-active', on);
					t.setAttribute('aria-pressed', on ? 'true' : 'false');
				});
				apply();
			});
		});

		if (input) { input.addEventListener('input', apply); }
	}

	function boot() {
		[].slice.call(document.querySelectorAll('.iag-lib')).forEach(init);
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', boot);
	} else {
		boot();
	}
})();
