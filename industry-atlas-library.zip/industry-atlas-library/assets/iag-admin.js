jQuery(function ($) {
	var frame;
	$('.iag-pick-file').on('click', function (e) {
		e.preventDefault();
		if (frame) { frame.open(); return; }
		frame = wp.media({ title: 'Select or upload a file', button: { text: 'Use this file' }, multiple: false });
		frame.on('select', function () {
			var file = frame.state().get('selection').first().toJSON();
			$('#iag_file_url').val(file.url);
		});
		frame.open();
	});
});
