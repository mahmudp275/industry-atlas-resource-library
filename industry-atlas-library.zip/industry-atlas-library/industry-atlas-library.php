<?php
/**
 * Plugin Name: Industry Atlas Library
 * Description: Adds "Free Resources" (downloads) and "Manufacturing News" (articles & press releases) with ready-made designs. Use the shortcodes [iag_resources] and [iag_news].
 * Version: 1.0.0
 * Author: Industry Atlas Group
 * License: GPL-2.0-or-later
 * Text Domain: iag-library
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'IAG_LIB_VER', '1.0.0' );
define( 'IAG_LIB_URL', plugin_dir_url( __FILE__ ) );

final class IAG_Library {

	/* ------------------------------------------------------------------
	 * Boot
	 * ---------------------------------------------------------------- */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_action( 'init', array( __CLASS__, 'register_assets' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_box' ) );
		add_action( 'save_post_iag_resource', array( __CLASS__, 'save_meta' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'admin_assets' ) );
		add_action( 'admin_menu', array( __CLASS__, 'settings_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'settings_register' ) );
		add_shortcode( 'iag_resources', array( __CLASS__, 'shortcode' ) );
		add_shortcode( 'iag_news', array( __CLASS__, 'shortcode' ) );
	}

	public static function activate() {
		self::register();
		foreach ( array( 'Visibility', 'Suppliers', 'Certification' ) as $term ) {
			if ( ! term_exists( $term, 'iag_resource_cat' ) ) {
				wp_insert_term( $term, 'iag_resource_cat' );
			}
		}
		foreach ( array( 'Articles', 'Press Releases' ) as $term ) {
			if ( ! term_exists( $term, 'iag_news_type' ) ) {
				wp_insert_term( $term, 'iag_news_type' );
			}
		}
		flush_rewrite_rules();
	}

	/* ------------------------------------------------------------------
	 * Post types & taxonomies
	 * ---------------------------------------------------------------- */
	public static function register() {
		register_post_type( 'iag_resource', array(
			'labels'       => array(
				'name'          => 'Free Resources',
				'singular_name' => 'Resource',
				'menu_name'     => 'Free Resources',
				'all_items'     => 'All Resources',
				'add_new'       => 'Add Resource',
				'add_new_item'  => 'Add New Resource',
				'edit_item'     => 'Edit Resource',
				'not_found'     => 'No resources found.',
			),
			'public'       => false,
			'show_ui'      => true,
			'show_in_rest' => true,
			'menu_icon'    => 'dashicons-download',
			'menu_position'=> 26,
			'supports'     => array( 'title', 'excerpt' ),
			'rewrite'      => false,
			'has_archive'  => false,
		) );

		register_taxonomy( 'iag_resource_cat', array( 'iag_resource' ), array(
			'labels'            => array(
				'name'          => 'Resource Categories',
				'singular_name' => 'Resource Category',
				'add_new_item'  => 'Add New Category',
			),
			'hierarchical'      => true,
			'public'            => false,
			'show_ui'           => true,
			'show_admin_column' => true,
			'show_in_rest'      => true,
			'rewrite'           => false,
		) );

		register_post_type( 'iag_news', array(
			'labels'       => array(
				'name'          => 'Manufacturing News',
				'singular_name' => 'News Post',
				'menu_name'     => 'Manufacturing News',
				'all_items'     => 'All News',
				'add_new'       => 'Add News',
				'add_new_item'  => 'Add New Article / Press Release',
				'edit_item'     => 'Edit News',
				'not_found'     => 'No news found.',
			),
			'public'       => true,
			'show_in_rest' => true,
			'menu_icon'    => 'dashicons-megaphone',
			'menu_position'=> 25,
			'supports'     => array( 'title', 'editor', 'excerpt', 'thumbnail' ),
			'rewrite'      => array( 'slug' => 'news', 'with_front' => false ),
			'has_archive'  => false,
		) );

		register_taxonomy( 'iag_news_type', array( 'iag_news' ), array(
			'labels'            => array(
				'name'          => 'News Types',
				'singular_name' => 'News Type',
				'add_new_item'  => 'Add New Type',
			),
			'hierarchical'      => true,
			'public'            => false,
			'show_ui'           => true,
			'show_admin_column' => true,
			'show_in_rest'      => true,
			'rewrite'           => false,
		) );
	}

	/* ------------------------------------------------------------------
	 * Admin: file field for resources
	 * ---------------------------------------------------------------- */
	public static function add_meta_box() {
		add_meta_box( 'iag_file', 'Downloadable File', array( __CLASS__, 'file_box' ), 'iag_resource', 'normal', 'high' );
	}

	public static function file_box( $post ) {
		wp_nonce_field( 'iag_file_save', 'iag_file_nonce' );
		$url   = get_post_meta( $post->ID, '_iag_file_url', true );
		$label = get_post_meta( $post->ID, '_iag_btn_label', true );
		?>
		<p><label for="iag_file_url"><strong>File</strong> (upload a PDF, DOCX, XLSX, ZIP... or paste any link)</label></p>
		<p style="display:flex;gap:8px;align-items:center;">
			<input type="url" id="iag_file_url" name="iag_file_url" value="<?php echo esc_attr( $url ); ?>" class="widefat" placeholder="https://">
			<button type="button" class="button iag-pick-file">Select / Upload File</button>
		</p>
		<p><label for="iag_btn_label"><strong>Button text</strong> (optional, default is set in Settings → Atlas Library)</label></p>
		<p><input type="text" id="iag_btn_label" name="iag_btn_label" value="<?php echo esc_attr( $label ); ?>" class="regular-text" placeholder="Download"></p>
		<p class="description">The title and the short description (Excerpt box below) are shown on the card.</p>
		<?php
	}

	public static function save_meta( $post_id ) {
		if ( ! isset( $_POST['iag_file_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['iag_file_nonce'] ) ), 'iag_file_save' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$url   = isset( $_POST['iag_file_url'] ) ? esc_url_raw( wp_unslash( $_POST['iag_file_url'] ) ) : '';
		$label = isset( $_POST['iag_btn_label'] ) ? sanitize_text_field( wp_unslash( $_POST['iag_btn_label'] ) ) : '';
		update_post_meta( $post_id, '_iag_file_url', $url );
		update_post_meta( $post_id, '_iag_btn_label', $label );
	}

	public static function admin_assets( $hook ) {
		$screen = get_current_screen();
		if ( $screen && 'iag_resource' === $screen->post_type && in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
			wp_enqueue_media();
			wp_enqueue_script( 'iag-admin', IAG_LIB_URL . 'assets/iag-admin.js', array( 'jquery' ), IAG_LIB_VER, true );
		}
	}

	/* ------------------------------------------------------------------
	 * Settings
	 * ---------------------------------------------------------------- */
	public static function defaults() {
		return array(
			'primary'    => '#0B2E4F',
			'text'       => '#5D6D7E',
			'soft'       => '#E8EEF4',
			'border'     => '#E1E7EE',
			'load_fonts' => 1,
			'btn_label'  => 'Download',
		);
	}

	public static function opts() {
		return wp_parse_args( (array) get_option( 'iag_lib_settings', array() ), self::defaults() );
	}

	public static function settings_menu() {
		add_options_page( 'Atlas Library', 'Atlas Library', 'manage_options', 'iag-library', array( __CLASS__, 'settings_page' ) );
	}

	public static function settings_register() {
		register_setting( 'iag_lib', 'iag_lib_settings', array( 'sanitize_callback' => array( __CLASS__, 'sanitize' ) ) );
	}

	public static function sanitize( $in ) {
		$d   = self::defaults();
		$out = array();
		foreach ( array( 'primary', 'text', 'soft', 'border' ) as $k ) {
			$c         = isset( $in[ $k ] ) ? sanitize_hex_color( $in[ $k ] ) : '';
			$out[ $k ] = $c ? $c : $d[ $k ];
		}
		$out['load_fonts'] = empty( $in['load_fonts'] ) ? 0 : 1;
		$out['btn_label']  = ! empty( $in['btn_label'] ) ? sanitize_text_field( $in['btn_label'] ) : $d['btn_label'];
		return $out;
	}

	public static function settings_page() {
		$o = self::opts();
		?>
		<div class="wrap">
			<h1>Atlas Library</h1>
			<form method="post" action="options.php">
				<?php settings_fields( 'iag_lib' ); ?>
				<table class="form-table" role="presentation">
					<tr><th>Main color (headings, buttons)</th><td><input type="color" name="iag_lib_settings[primary]" value="<?php echo esc_attr( $o['primary'] ); ?>"></td></tr>
					<tr><th>Text color</th><td><input type="color" name="iag_lib_settings[text]" value="<?php echo esc_attr( $o['text'] ); ?>"></td></tr>
					<tr><th>Icon box color</th><td><input type="color" name="iag_lib_settings[soft]" value="<?php echo esc_attr( $o['soft'] ); ?>"></td></tr>
					<tr><th>Border color</th><td><input type="color" name="iag_lib_settings[border]" value="<?php echo esc_attr( $o['border'] ); ?>"></td></tr>
					<tr><th>Default download button text</th><td><input type="text" name="iag_lib_settings[btn_label]" value="<?php echo esc_attr( $o['btn_label'] ); ?>" class="regular-text"></td></tr>
					<tr><th>Fonts</th><td><label><input type="checkbox" name="iag_lib_settings[load_fonts]" value="1" <?php checked( $o['load_fonts'], 1 ); ?>> Load Montserrat (headings) and Open Sans (text) from Google Fonts. Untick to use your theme's fonts.</label></td></tr>
				</table>
				<?php submit_button(); ?>
			</form>
			<hr>
			<h2>How to use</h2>
			<p><strong>1.</strong> Add content: <em>Free Resources → Add Resource</em> and <em>Manufacturing News → Add News</em>. Pick a category (Visibility, Suppliers, Certification / Articles, Press Releases) on the right side. You can add or rename categories any time.</p>
			<p><strong>2.</strong> Put this shortcode on a page (Elementor "Shortcode" widget or a Gutenberg "Shortcode" block):</p>
			<p><code>[iag_resources]</code> &nbsp;for the free downloads library<br><code>[iag_news]</code> &nbsp;for the Manufacturing News list</p>
			<p><strong>Options:</strong> <code>columns="3"</code> (1–4), <code>limit="60"</code>, <code>search="no"</code>, <code>tabs="no"</code>, <code>category="slug"</code>, <code>all_label="All"</code>, <code>placeholder="Search..."</code>, <code>empty_title="..."</code>, <code>empty_text="..."</code></p>
			<p>Example: <code>[iag_resources columns="2" empty_title="Coming soon"]</code></p>
		</div>
		<?php
	}

	/* ------------------------------------------------------------------
	 * Front end
	 * ---------------------------------------------------------------- */
	public static function register_assets() {
		wp_register_style( 'iag-fonts', 'https://fonts.googleapis.com/css2?family=Montserrat:wght@600;700;800&family=Open+Sans:wght@400;600&display=swap', array(), null );
		wp_register_style( 'iag-library', IAG_LIB_URL . 'assets/iag-library.css', array(), IAG_LIB_VER );
		wp_register_script( 'iag-library', IAG_LIB_URL . 'assets/iag-library.js', array(), IAG_LIB_VER, true );
	}

	private static function svg( $name ) {
		$icons = array(
			'download' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3v12m0 0l-4.5-4.5M12 15l4.5-4.5M4 17v2a2 2 0 002 2h12a2 2 0 002-2v-2"/></svg>',
			'doc'      => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8zM14 3v5h5M9 13h6M9 17h6"/></svg>',
			'news'     => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 4h12a2 2 0 012 2v13a1 1 0 01-1 1H6a2 2 0 01-2-2V5a1 1 0 011-1zM8 9h7M8 13h7M8 17h4"/></svg>',
			'search'   => '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>',
		);
		return isset( $icons[ $name ] ) ? $icons[ $name ] : '';
	}

	public static function shortcode( $atts, $content = '', $tag = 'iag_resources' ) {
		static $n = 0;
		$n++;

		$is_news   = ( 'iag_news' === $tag );
		$post_type = $is_news ? 'iag_news' : 'iag_resource';
		$taxonomy  = $is_news ? 'iag_news_type' : 'iag_resource_cat';
		$o         = self::opts();

		$a = shortcode_atts( array(
			'limit'       => 60,
			'columns'     => 3,
			'search'      => 'yes',
			'tabs'        => 'yes',
			'category'    => '',
			'all_label'   => $is_news ? 'All Updates' : 'All Resources',
			'placeholder' => $is_news ? 'Search news...' : 'Search resources...',
			'empty_title' => $is_news ? 'Manufacturing news is coming soon' : 'Free resources are coming soon',
			'empty_text'  => $is_news ? 'Articles, press releases, and industry announcements will appear here when published.' : 'Downloadable guides, tools, and educational materials will appear here when published.',
		), $atts, $tag );

		$cols = max( 1, min( 4, (int) $a['columns'] ) );

		$args = array(
			'post_type'      => $post_type,
			'post_status'    => 'publish',
			'posts_per_page' => (int) $a['limit'],
			'orderby'        => 'date',
			'order'          => 'DESC',
			'no_found_rows'  => true,
		);
		if ( $a['category'] ) {
			$args['tax_query'] = array( array( 'taxonomy' => $taxonomy, 'field' => 'slug', 'terms' => array_map( 'sanitize_title', explode( ',', $a['category'] ) ) ) );
		}
		$q = new WP_Query( $args );

		if ( $o['load_fonts'] ) {
			wp_enqueue_style( 'iag-fonts' );
		}
		wp_enqueue_style( 'iag-library' );
		wp_enqueue_script( 'iag-library' );

		$style = sprintf(
			'--iag-primary:%s;--iag-text:%s;--iag-soft:%s;--iag-border:%s;--iag-cols:%d;--iag-head:%s;--iag-body:%s;',
			esc_attr( $o['primary'] ), esc_attr( $o['text'] ), esc_attr( $o['soft'] ), esc_attr( $o['border'] ), $cols,
			$o['load_fonts'] ? "'Montserrat',sans-serif" : 'inherit',
			$o['load_fonts'] ? "'Open Sans',sans-serif" : 'inherit'
		);

		ob_start();
		?>
		<div class="iag-lib" id="iag-lib-<?php echo (int) $n; ?>" style="<?php echo $style; // phpcs:ignore WordPress.Security.EscapeOutput ?>">

			<?php
			$show_tabs   = ( 'no' !== $a['tabs'] && ! $a['category'] );
			$show_search = ( 'no' !== $a['search'] );
			if ( $show_tabs || $show_search ) :
				$terms = $show_tabs ? get_terms( array( 'taxonomy' => $taxonomy, 'hide_empty' => false ) ) : array();
				?>
				<div class="iag-bar">
					<div class="iag-tabs">
						<?php if ( $show_tabs ) : ?>
							<button type="button" class="iag-tab is-active" data-filter="all" aria-pressed="true"><?php echo esc_html( $a['all_label'] ); ?></button>
							<?php if ( ! is_wp_error( $terms ) ) : foreach ( $terms as $t ) : ?>
								<button type="button" class="iag-tab" data-filter="<?php echo esc_attr( $t->slug ); ?>" aria-pressed="false"><?php echo esc_html( $t->name ); ?></button>
							<?php endforeach; endif; ?>
						<?php endif; ?>
					</div>
					<?php if ( $show_search ) : ?>
						<label class="iag-search">
							<span class="screen-reader-text" style="position:absolute;left:-9999px;"><?php echo esc_html( $a['placeholder'] ); ?></span>
							<input type="search" class="iag-search__input" placeholder="<?php echo esc_attr( $a['placeholder'] ); ?>">
							<?php echo self::svg( 'search' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
						</label>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<?php if ( $q->have_posts() ) : ?>
				<div class="iag-grid">
					<?php
					while ( $q->have_posts() ) :
						$q->the_post();
						$id    = get_the_ID();
						$terms = get_the_terms( $id, $taxonomy );
						$slugs = array();
						$names = array();
						if ( $terms && ! is_wp_error( $terms ) ) {
							foreach ( $terms as $t ) {
								$slugs[] = $t->slug;
								$names[] = $t->name;
							}
						}
						$excerpt = has_excerpt( $id ) ? get_the_excerpt() : wp_trim_words( wp_strip_all_tags( get_the_content() ), 24 );
						$search  = function_exists( 'mb_strtolower' ) ? mb_strtolower( get_the_title() . ' ' . $excerpt . ' ' . implode( ' ', $names ) ) : strtolower( get_the_title() . ' ' . $excerpt . ' ' . implode( ' ', $names ) );
						?>
						<article class="iag-card <?php echo $is_news ? 'iag-card--news' : 'iag-card--res'; ?>" data-cats="<?php echo esc_attr( implode( ' ', $slugs ) ); ?>" data-search="<?php echo esc_attr( $search ); ?>">
							<?php if ( $is_news ) : ?>
								<?php if ( has_post_thumbnail( $id ) ) : ?>
									<a class="iag-card__img" href="<?php the_permalink(); ?>"><?php echo get_the_post_thumbnail( $id, 'medium_large', array( 'loading' => 'lazy' ) ); ?></a>
								<?php endif; ?>
								<div class="iag-card__meta"><?php echo esc_html( get_the_date() ); ?><?php echo $names ? ' &middot; ' . esc_html( $names[0] ) : ''; ?></div>
								<h3 class="iag-card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
								<?php if ( $excerpt ) : ?><p class="iag-card__text"><?php echo esc_html( $excerpt ); ?></p><?php endif; ?>
								<a class="iag-link" href="<?php the_permalink(); ?>">Read More <span aria-hidden="true">&rarr;</span></a>
							<?php else : ?>
								<?php
								$file  = get_post_meta( $id, '_iag_file_url', true );
								$label = get_post_meta( $id, '_iag_btn_label', true );
								$label = $label ? $label : $o['btn_label'];
								$ext   = $file ? strtoupper( pathinfo( (string) wp_parse_url( $file, PHP_URL_PATH ), PATHINFO_EXTENSION ) ) : '';
								$ext   = ( $ext && strlen( $ext ) <= 5 ) ? $ext : 'FILE';
								?>
								<div class="iag-card__icon"><?php echo self::svg( 'doc' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
								<div class="iag-card__meta"><?php echo esc_html( $file ? $ext : 'RESOURCE' ); ?><?php echo $names ? ' &middot; ' . esc_html( $names[0] ) : ''; ?></div>
								<h3 class="iag-card__title"><?php the_title(); ?></h3>
								<?php if ( $excerpt ) : ?><p class="iag-card__text"><?php echo esc_html( $excerpt ); ?></p><?php endif; ?>
								<?php if ( $file ) : ?>
									<a class="iag-link" href="<?php echo esc_url( $file ); ?>" download target="_blank" rel="noopener"><?php echo esc_html( $label ); ?> <span aria-hidden="true">&rarr;</span></a>
								<?php endif; ?>
							<?php endif; ?>
						</article>
					<?php endwhile; wp_reset_postdata(); ?>
				</div>

				<div class="iag-empty iag-empty--filter" hidden>
					<div class="iag-empty__icon"><?php echo self::svg( 'search' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
					<h3>No results found</h3>
					<p>Try a different category or search term.</p>
				</div>
			<?php else : ?>
				<div class="iag-empty">
					<div class="iag-empty__icon"><?php echo self::svg( $is_news ? 'news' : 'download' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
					<h3><?php echo esc_html( $a['empty_title'] ); ?></h3>
					<p><?php echo esc_html( $a['empty_text'] ); ?></p>
				</div>
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}
}

register_activation_hook( __FILE__, array( 'IAG_Library', 'activate' ) );
register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );
IAG_Library::init();
