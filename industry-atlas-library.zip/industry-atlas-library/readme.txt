=== Industry Atlas Library ===
Version: 1.0.0

Adds two content types with ready-made designs:
- Free Resources (downloadable files)  -> shortcode [iag_resources]
- Manufacturing News (articles & press releases) -> shortcode [iag_news]

INSTALL
Plugins > Add New > Upload Plugin > choose industry-atlas-library.zip > Activate.

ADD CONTENT
Free Resources > Add Resource: title, short description (Excerpt), upload file, pick a category.
Manufacturing News > Add News: title, content, excerpt, featured image, pick Articles or Press Releases.

SHOW ON A PAGE
Add a Shortcode widget (Elementor) or Shortcode block (Gutenberg) and paste:
[iag_resources]
[iag_news]

OPTIONS
columns="3" (1-4)   limit="60"   search="no"   tabs="no"   category="slug"
all_label="All"   placeholder="Search..."   empty_title="..."   empty_text="..."

COLORS / FONTS
Settings > Atlas Library.
